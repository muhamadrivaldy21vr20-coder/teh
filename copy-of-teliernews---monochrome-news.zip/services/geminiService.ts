
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

/**
 * Edits an image using the Gemini 2.5 Flash Image model.
 * Following Google GenAI SDK best practices, we initialize a fresh client 
 * for each request and iterate through response parts to find the image output.
 */
export const editImageWithGemini = async (base64Image: string, prompt: string, mimeType: string = 'image/png'): Promise<string | null> => {
  try {
    // ALWAYS initialize the client directly with process.env.API_KEY right before the call
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Using the recommended model for image editing tasks
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              // Extract the base64 payload if a data URL is provided
              data: base64Image.includes(',') ? base64Image.split(',')[1] : base64Image,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    // Iterate through all candidates and parts to find the modified image
    if (response.candidates && response.candidates[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64EncodeString: string = part.inlineData.data;
          // Return the full data URI for the generated image
          return `data:${part.inlineData.mimeType || 'image/png'};base64,${base64EncodeString}`;
        }
      }
    }
    
    return null;
  } catch (error) {
    console.error("Error editing image with Gemini:", error);
    throw error;
  }
};
