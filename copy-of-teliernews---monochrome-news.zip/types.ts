
export type Category = 'Teknologi' | 'Ekonomi' | 'Politik' | 'Geopolitik' | 'Bisnis' | 'Internasional' | 'AI' | 'Market' | 'Culture';

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content?: string;
  category: Category;
  date: string;
  imageUrl: string;
  author: string;
  views?: number;
}

export interface User {
  name: string;
  email: string;
  role: 'admin' | 'reader';
  membership: 'Standard' | 'Premium' | 'Pro';
}

/**
 * Interface representing market data for the ticker component.
 */
export interface MarketData {
  symbol: string;
  price: string;
  change: string;
  isPositive: boolean;
}
