
import React, { useState, useMemo, useEffect } from 'react';
import Navbar from './components/Navbar';
import NewsCard from './components/NewsCard';
import LoginPage from './components/LoginPage';
import ProfileOverlay from './components/ProfileOverlay';
import MarketTicker from './components/MarketTicker';
import AdminDashboard from './components/AdminDashboard';
import ArticleEditor from './components/ArticleEditor';
import { MOCK_ARTICLES } from './constants';
import { Category, User, Article } from './types';

const App: React.FC = () => {
  // Persistence & State
  const [articles, setArticles] = useState<Article[]>(() => {
    const saved = localStorage.getItem('telier_articles');
    return saved ? JSON.parse(saved) : MOCK_ARTICLES;
  });
  
  const [activeCategory, setActiveCategory] = useState<Category | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<'public' | 'admin'>('public');
  
  // UI Overlays
  const [showLogin, setShowLogin] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
    localStorage.setItem('telier_articles', JSON.stringify(articles));
  }, [articles]);

  const filteredArticles = useMemo(() => {
    if (!activeCategory) return articles;
    return articles.filter(a => a.category === activeCategory);
  }, [activeCategory, articles]);

  const handleLoginSuccess = (name: string, email: string) => {
    // Check for admin keyword for demonstration
    const role = email.toLowerCase().includes('admin') ? 'admin' : 'reader';
    setUser({ name, email, role, membership: 'Pro' });
    setShowLogin(false);
    
    if (role === 'admin') {
      setTimeout(() => setView('admin'), 500);
    }
  };

  const handleSaveArticle = (data: Partial<Article>) => {
    if (editingArticle) {
      setArticles(prev => prev.map(a => a.id === editingArticle.id ? { ...a, ...data } : a));
    } else {
      const newArticle: Article = {
        id: Date.now().toString(),
        title: data.title || 'Tanpa Judul',
        excerpt: data.excerpt || '',
        content: data.content || '',
        category: data.category || 'Teknologi',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase(),
        imageUrl: data.imageUrl || 'https://picsum.photos/800/600',
        author: data.author || 'Admin',
        views: 0
      };
      setArticles(prev => [newArticle, ...prev]);
    }
    setShowEditor(false);
    setEditingArticle(null);
  };

  const handleDeleteArticle = (id: string) => {
    if (window.confirm("Konfirmasi penghapusan unit intelijen ini?")) {
      setArticles(prev => prev.filter(a => a.id !== id));
    }
  };

  if (view === 'admin' && user?.role === 'admin') {
    return (
      <div className="bg-white min-h-screen">
        <Navbar 
          onCategorySelect={() => {}} 
          activeCategory={null}
          user={user}
          onLoginClick={() => {}}
          onProfileClick={() => setShowProfile(true)}
        />
        <AdminDashboard 
          articles={articles}
          onAddClick={() => { setEditingArticle(null); setShowEditor(true); }}
          onEditClick={(a) => { setEditingArticle(a); setShowEditor(true); }}
          onDeleteClick={handleDeleteArticle}
          onExit={() => setView('public')}
        />
        {showEditor && (
          <ArticleEditor 
            article={editingArticle}
            onSave={handleSaveArticle}
            onCancel={() => { setShowEditor(false); setEditingArticle(null); }}
          />
        )}
        <ProfileOverlay 
          user={user}
          isOpen={showProfile}
          onClose={() => setShowProfile(false)}
          onLogout={() => { setUser(null); setView('public'); }}
        />
      </div>
    );
  }

  return (
    <div className={`min-h-screen flex flex-col bg-white text-black selection:bg-black selection:text-white transition-opacity duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
      <Navbar 
        onCategorySelect={setActiveCategory} 
        activeCategory={activeCategory}
        user={user}
        onLoginClick={() => setShowLogin(true)}
        onProfileClick={() => setShowProfile(true)}
      />
      
      <MarketTicker />

      <main className="flex-grow max-w-[1400px] mx-auto px-6 w-full pt-10 pb-24">
        
        {/* HEADER */}
        <div className="mb-20 pb-12 border-b border-black flex flex-col md:flex-row justify-between items-end gap-6">
          <div className="space-y-4">
            <p className="text-[10px] font-black tracking-[0.5em] text-zinc-400 uppercase">Intelligence Dispatch // Live</p>
            <h2 className="text-6xl md:text-8xl font-black tracking-tighter uppercase leading-[0.85]">
              {activeCategory || 'Headline Utama'}
            </h2>
          </div>
          <div className="flex flex-col items-end text-right">
             <span className="text-[10px] font-bold tracking-widest text-zinc-400 uppercase mb-1">Jakarta // Edisi</span>
             <span className="text-[12px] font-black tracking-widest uppercase">
                {new Date().toLocaleDateString('id-ID', { weekday: 'long', month: 'long', day: 'numeric' })}
             </span>
             {user?.role === 'admin' && (
               <button 
                onClick={() => setView('admin')}
                className="mt-4 text-[9px] font-black tracking-widest uppercase bg-black text-white px-4 py-2 hover:bg-zinc-800 transition-all"
               >
                 Open Terminal
               </button>
             )}
          </div>
        </div>

        {/* FEATURED STORY */}
        {filteredArticles[0] && (
          <NewsCard article={filteredArticles[0]} featured />
        )}

        {/* GRID LAYOUT */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mt-20">
           <div className="lg:col-span-4 border-r border-zinc-100 pr-10 space-y-12">
              <h4 className="text-[10px] font-black tracking-[0.3em] uppercase pb-4 border-b border-black">Top Intelligence</h4>
              {filteredArticles.slice(1, 4).map(article => (
                <NewsCard key={article.id} article={article} />
              ))}
           </div>

           <div className="lg:col-span-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
                {filteredArticles.slice(4).map(article => (
                  <NewsCard key={article.id} article={article} />
                ))}
              </div>
              {filteredArticles.length === 0 && (
                <div className="h-64 flex flex-col items-center justify-center border border-dashed border-zinc-100 text-zinc-200">
                  <p className="font-black text-xl uppercase tracking-widest">Data Tidak Tersedia</p>
                </div>
              )}
           </div>
        </div>

        {/* NEWSLETTER CTA */}
        {!activeCategory && (
           <section className="mt-32 pt-24 border-t border-black grid grid-cols-1 lg:grid-cols-2 gap-20">
              <div>
                <h3 className="text-4xl md:text-6xl font-black tracking-tighter uppercase mb-6 leading-none">
                  Kekuatan <br/> <span className="text-zinc-400">Informasi.</span>
                </h3>
                <p className="text-sm font-light text-zinc-500 max-w-sm leading-relaxed mb-10 uppercase tracking-widest">
                  Bergabunglah dengan 1,2 juta pemimpin global dalam memahami kompleksitas AI dan Geopolitik.
                </p>
                <div className="w-full max-w-md flex flex-col sm:flex-row border-b border-black">
                  <input 
                    type="email" 
                    placeholder="IDENTITY@AGENCY.COM"
                    className="flex-grow bg-transparent py-4 text-[10px] font-bold tracking-widest focus:outline-none uppercase"
                  />
                  <button className="bg-black text-white px-10 py-4 text-[10px] font-black tracking-widest uppercase hover:bg-zinc-800 transition-colors">
                    Initialize
                  </button>
                </div>
              </div>
              <div className="hidden lg:flex items-center justify-center">
                 <div className="w-64 h-64 border border-zinc-100 p-6 flex flex-col justify-between">
                    <p className="text-[9px] font-black tracking-widest text-zinc-300 uppercase">Pro Access</p>
                    <div>
                      <h4 className="text-2xl font-black uppercase tracking-tighter">$120/YR</h4>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase mt-2">Unlimited Intelligence access on all platforms.</p>
                    </div>
                 </div>
              </div>
           </section>
        )}
      </main>

      {/* OVERLAYS */}
      {showLogin && (
        <LoginPage 
          onLoginSuccess={handleLoginSuccess}
          onClose={() => setShowLogin(false)}
        />
      )}
      
      {user && (
        <ProfileOverlay 
          user={user}
          isOpen={showProfile}
          onClose={() => setShowProfile(false)}
          onLogout={() => { setUser(null); setView('public'); }}
        />
      )}

      {/* FOOTER */}
      <footer className="bg-black text-white pt-32 pb-16 px-6 mt-20">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-32">
            <div className="col-span-2">
              <h1 className="text-2xl font-black tracking-tighter mb-10 uppercase">
                TELIER<span className="text-zinc-600">.</span>
              </h1>
              <p className="text-zinc-600 max-w-xs text-[10px] leading-relaxed font-bold uppercase tracking-[0.3em]">
                Intelijen radikal yang transparan. Berdiri sejak MMXXV.
              </p>
            </div>
            <div className="space-y-6">
              <h4 className="font-black text-[9px] tracking-[0.4em] uppercase text-zinc-500">Legal</h4>
              <ul className="space-y-4 text-[10px] font-bold tracking-widest text-zinc-700 uppercase">
                <li><a href="#" className="hover:text-zinc-400 transition-colors">Privacy</a></li>
                <li><a href="#" className="hover:text-zinc-400 transition-colors">Ethics</a></li>
                <li><a href="#" className="hover:text-zinc-400 transition-colors">Access</a></li>
              </ul>
            </div>
            <div className="space-y-6">
              <h4 className="font-black text-[9px] tracking-[0.4em] uppercase text-zinc-500">Connect</h4>
              <div className="flex gap-8 text-zinc-600 text-xl">
                <i className="fa-brands fa-x-twitter hover:text-white cursor-pointer transition-colors"></i>
                <i className="fa-brands fa-linkedin-in hover:text-white cursor-pointer transition-colors"></i>
              </div>
            </div>
          </div>
          <div className="pt-10 border-t border-zinc-900 text-[9px] font-black tracking-[0.5em] text-zinc-800 uppercase flex justify-between">
            <p>© 2025 TELIER MEDIA GROUP GLOBAL LLC.</p>
            <p>DESIGNED IN JAKARTA</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
