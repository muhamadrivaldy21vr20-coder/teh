
import React from 'react';
import { Article } from '../types';

interface NewsCardProps {
  article: Article;
  featured?: boolean;
}

const NewsCard: React.FC<NewsCardProps> = ({ article, featured }) => {
  if (featured) {
    return (
      <div className="group cursor-pointer mb-20 animate-slide-up">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 overflow-hidden bg-zinc-50 relative aspect-[21/9]">
             <img 
              src={article.imageUrl} 
              alt={article.title}
              className="w-full h-full object-cover img-luxury"
            />
            <div className="absolute top-4 left-4">
              <span className="text-[10px] font-black tracking-[0.4em] bg-white text-black px-3 py-1 uppercase shadow-xl">Lead Story</span>
            </div>
          </div>
          <div className="lg:col-span-4 flex flex-col justify-center border-l border-zinc-100 lg:pl-10">
            <div className="flex items-center gap-3 mb-6">
              <span className="text-[9px] font-bold tracking-[0.3em] text-zinc-300 uppercase">{article.category}</span>
              <div className="w-10 h-[1px] bg-zinc-100"></div>
              <span className="text-[9px] font-bold tracking-[0.3em] text-zinc-300 uppercase">{article.date}</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-black leading-[1.1] mb-6 tracking-tight uppercase group-hover:opacity-60 transition-opacity">
              {article.title}
            </h2>
            <p className="text-zinc-500 text-sm mb-8 leading-relaxed font-light">
              {article.excerpt}
            </p>
            <div className="flex items-center gap-3 pt-6 border-t border-zinc-100">
               <div className="w-6 h-6 bg-black rounded-full"></div>
               <span className="text-[10px] font-bold tracking-widest uppercase">Report by {article.author}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group cursor-pointer animate-slide-up stagger-1 pb-10 border-b border-zinc-100 last:border-0 last:pb-0">
      <div className="overflow-hidden bg-zinc-50 aspect-[16/10] mb-6">
        <img 
          src={article.imageUrl} 
          alt={article.title}
          className="w-full h-full object-cover img-luxury"
        />
      </div>
      <div className="flex items-center gap-2 mb-4">
        <span className="text-[9px] font-black tracking-[0.3em] text-black uppercase">{article.category}</span>
        <span className="text-zinc-200">•</span>
        <span className="text-[9px] font-bold tracking-[0.3em] text-zinc-300 uppercase">{article.date}</span>
      </div>
      <h3 className="text-lg font-black leading-tight mb-4 tracking-tight uppercase group-hover:text-zinc-400 transition-colors">
        {article.title}
      </h3>
      <p className="text-zinc-400 text-xs mb-6 leading-relaxed line-clamp-2 font-light">
        {article.excerpt}
      </p>
      <div className="text-[9px] font-bold tracking-widest text-zinc-300 uppercase">
        {article.author}
      </div>
    </div>
  );
};

export default NewsCard;
