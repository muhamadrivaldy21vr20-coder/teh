
import React, { useState, useRef } from 'react';
import { editImageWithGemini } from '../services/geminiService';

interface ImageLabProps {
  onClose: () => void;
}

const ImageLab: React.FC<ImageLabProps> = ({ onClose }) => {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEdit = async () => {
    if (!image || !prompt) return;
    setIsProcessing(true);
    setError(null);
    try {
      const editedImageUrl = await editImageWithGemini(image, prompt);
      if (editedImageUrl) {
        setResult(editedImageUrl);
      } else {
        setError("Failed to generate edited image. The model might not have returned an image part.");
      }
    } catch (err) {
      setError("An error occurred during the image editing process. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const link = document.createElement('a');
    link.href = result;
    link.download = `telier-ai-edit-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-[110] bg-black/95 backdrop-blur-xl p-6 md:p-12 overflow-y-auto">
      <div className="max-w-6xl mx-auto h-full flex flex-col">
        <div className="flex justify-between items-start mb-12">
          <div>
            <h2 className="serif text-5xl font-bold mb-2">Telier AI Lab</h2>
            <p className="text-gray-500 tracking-widest uppercase text-sm">Vision Engine: Gemini 2.5 Flash</p>
          </div>
          <button 
            onClick={onClose}
            className="text-3xl p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 flex-grow">
          {/* Work Area */}
          <div className="space-y-8">
            <div className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center flex flex-col items-center justify-center min-h-[400px] relative group overflow-hidden">
              {image ? (
                <div className="relative w-full h-full flex items-center justify-center">
                  <img src={image} alt="Original" className="max-h-[400px] object-contain rounded-lg" />
                  <button 
                    onClick={() => setImage(null)}
                    className="absolute top-2 right-2 bg-black/50 p-2 rounded-full hover:bg-black/80"
                  >
                    <i className="fa-solid fa-trash"></i>
                  </button>
                </div>
              ) : (
                <div className="cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                  <div className="text-5xl mb-4 text-gray-700 group-hover:text-white transition-colors">
                    <i className="fa-solid fa-cloud-upload-alt"></i>
                  </div>
                  <p className="text-xl font-bold">Upload Source Image</p>
                  <p className="text-gray-500 text-sm mt-2">RAW, PNG, JPG accepted</p>
                </div>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*"
              />
            </div>

            <div className="space-y-4">
              <label className="block text-xs font-bold tracking-[0.3em] text-gray-500 uppercase">Modification Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g. 'Add a retro cinematic film grain', 'Remove the objects on the table', 'Convert this to a monochrome street photo style'"
                className="w-full bg-white/5 border border-white/10 rounded-xl p-4 min-h-[120px] focus:outline-none focus:border-white transition-colors text-lg"
              />
              <div className="flex flex-wrap gap-2">
                {["Retro filter", "Noir style", "HDR boost", "Clean background", "Warm atmosphere"].map(preset => (
                  <button 
                    key={preset}
                    onClick={() => setPrompt(prev => prev ? `${prev}, ${preset}` : preset)}
                    className="text-[10px] uppercase tracking-widest border border-white/20 px-3 py-1 rounded-full hover:bg-white hover:text-black transition-colors"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleEdit}
              disabled={!image || !prompt || isProcessing}
              className={`w-full py-6 rounded-xl font-bold text-xl transition-all ${
                !image || !prompt || isProcessing 
                ? 'bg-gray-800 text-gray-600 cursor-not-allowed' 
                : 'bg-white text-black hover:bg-gray-200'
              }`}
            >
              {isProcessing ? (
                <span className="flex items-center justify-center">
                  <i className="fa-solid fa-circle-notch fa-spin mr-3"></i> ANALYZING PIXELS...
                </span>
              ) : (
                'GENERATE MODIFICATION'
              )}
            </button>
          </div>

          {/* Result Area */}
          <div className="bg-white/5 rounded-2xl p-8 border border-white/10 flex flex-col">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-sm font-bold tracking-widest text-gray-500 uppercase">Processed Output</h3>
              {result && (
                <button 
                  onClick={handleDownload}
                  className="text-sm font-bold flex items-center hover:text-gray-300"
                >
                  <i className="fa-solid fa-download mr-2"></i> DOWNLOAD
                </button>
              )}
            </div>

            <div className="flex-grow flex flex-col items-center justify-center bg-black/50 rounded-xl overflow-hidden relative">
              {isProcessing && (
                <div className="absolute inset-0 z-10 bg-black/40 flex flex-col items-center justify-center space-y-4">
                  <div className="w-12 h-1 bg-white/20 overflow-hidden rounded-full">
                    <div className="w-full h-full bg-white animate-[loading_1.5s_infinite]"></div>
                  </div>
                  <p className="text-xs tracking-[0.5em] text-white/50">PROCESSING TENSORS</p>
                </div>
              )}
              
              {error && (
                <div className="p-8 text-center text-red-500">
                  <i className="fa-solid fa-exclamation-triangle text-3xl mb-4"></i>
                  <p className="font-bold">{error}</p>
                </div>
              )}

              {result ? (
                <img src={result} alt="Result" className="max-w-full max-h-[500px] object-contain" />
              ) : !isProcessing && (
                <div className="text-gray-700 text-center">
                  <i className="fa-solid fa-microchip text-6xl mb-4 opacity-20"></i>
                  <p className="uppercase tracking-widest text-sm opacity-40">Ready for generation</p>
                </div>
              )}
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="p-4 border border-white/5 rounded-lg">
                <p className="text-[10px] text-gray-600 uppercase mb-1">Inference Time</p>
                <p className="text-lg font-bold">~4.2s</p>
              </div>
              <div className="p-4 border border-white/5 rounded-lg">
                <p className="text-[10px] text-gray-600 uppercase mb-1">Resolution</p>
                <p className="text-lg font-bold">Original</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

export default ImageLab;
