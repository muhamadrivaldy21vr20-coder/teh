
import React, { useState } from 'react';
import { CATEGORIES } from '../constants';
import { Category, User } from '../types';

interface NavbarProps {
  onCategorySelect: (cat: Category | null) => void;
  activeCategory: Category | null;
  user: User | null;
  onLoginClick: () => void;
  onProfileClick: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ 
  onCategorySelect, 
  activeCategory, 
  user, 
  onLoginClick, 
  onProfileClick 
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleCategoryClick = (cat: Category | null) => {
    onCategorySelect(cat);
    setIsMenuOpen(false);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 w-full z-[80] bg-white/90 backdrop-blur-xl border-b border-zinc-100 h-14 md:h-16">
        <div className="max-w-[1400px] mx-auto px-6 h-full flex items-center justify-between">
          
          {/* LEFT: Branding & Menu */}
          <div className="flex items-center gap-8">
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="group flex flex-col gap-1 justify-center items-start w-6 h-6 outline-none"
              aria-label="Open Menu"
            >
              <div className="w-6 h-[2px] bg-black"></div>
              <div className="w-6 h-[2px] bg-black"></div>
              <div className="w-4 h-[2px] bg-black group-hover:w-6 transition-all duration-300"></div>
            </button>
            
            <div 
              className="cursor-pointer select-none"
              onClick={() => {
                onCategorySelect(null);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              <h1 className="text-xl font-black tracking-[-0.05em] uppercase flex items-center">
                <span className="bg-black text-white px-1 mr-0.5">T</span>ELIER<span className="text-black font-black">.</span>
              </h1>
            </div>
          </div>

          {/* RIGHT: Status & Login */}
          <div className="flex items-center gap-6">
            {user?.role === 'admin' && (
              <span className="text-[8px] font-black tracking-[0.2em] uppercase bg-black text-white px-2 py-0.5 rounded-sm">
                ADMIN TERMINAL
              </span>
            )}
            
            <div className="hidden lg:flex gap-6 items-center border-r border-zinc-100 pr-6 mr-2">
               <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Live</span>
               <div className="w-2 h-2 rounded-full bg-black animate-pulse"></div>
            </div>
            
            <button 
              onClick={user ? onProfileClick : onLoginClick}
              className="group relative flex items-center justify-center w-9 h-9 border border-black hover:bg-black hover:text-white transition-all duration-300 overflow-hidden"
            >
              {user ? (
                <span className="text-[10px] font-black">{user.name.charAt(0).toUpperCase()}</span>
              ) : (
                <i className="fa-solid fa-user text-[10px]"></i>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* MONOCHROME HAMBURGER OVERLAY */}
      <div className={`fixed inset-0 z-[100] transition-all duration-700 ease-[cubic-bezier(0.19, 1, 0.22, 1)] ${isMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'}`}>
        <div className="absolute inset-0 bg-white"></div>
        
        {/* Top bar in menu */}
        <div className="relative h-14 md:h-16 border-b border-zinc-100 flex items-center px-6 max-w-[1400px] mx-auto justify-between">
           <h1 className="text-xl font-black uppercase"><span className="bg-black text-white px-1">T</span>ELIER</h1>
           <button 
             onClick={() => setIsMenuOpen(false)}
             className="text-black hover:opacity-50 transition-opacity"
           >
             <i className="fa-solid fa-xmark text-2xl"></i>
           </button>
        </div>

        <div className="relative max-w-[1400px] mx-auto p-6 md:p-12 h-[calc(100%-64px)] overflow-y-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
            
            {/* Left Section: Bloomberg-style Meta Links */}
            <div className="lg:col-span-4 space-y-12">
               <div className="space-y-6">
                 <p className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-400 border-b border-zinc-100 pb-2">Corporate</p>
                 <ul className="space-y-4">
                   {['About Telier', 'Contact Us', 'Press Inquiries', 'Careers', 'Advertise'].map(link => (
                     <li key={link}>
                       <a href="#" className="text-2xl font-bold hover:opacity-50 transition-opacity tracking-tighter uppercase">{link}</a>
                     </li>
                   ))}
                 </ul>
               </div>
               
               <div className="space-y-6">
                 <p className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-300 border-b border-zinc-100 pb-2">Solutions</p>
                 <ul className="space-y-4">
                   {['Subscription', 'Institutional Data', 'Terminal Access', 'Newsletters'].map(link => (
                     <li key={link}>
                       <a href="#" className="text-sm font-black uppercase tracking-widest text-zinc-400 hover:text-black transition-colors">{link}</a>
                     </li>
                   ))}
                 </ul>
               </div>
            </div>

            {/* Right Section: Main Categories */}
            <div className="lg:col-span-8">
               <p className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-300 border-b border-zinc-100 pb-2 mb-8">Sections</p>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-2">
                 <button 
                    onClick={() => handleCategoryClick(null)}
                    className={`group text-5xl md:text-7xl font-black text-left uppercase tracking-tighter py-3 border-b border-zinc-50 hover:border-black transition-all ${!activeCategory ? 'text-black opacity-100' : 'text-zinc-200 hover:text-black'}`}
                 >
                   Front Page
                 </button>
                 {CATEGORIES.map((cat) => (
                    <button 
                      key={cat}
                      onClick={() => handleCategoryClick(cat)}
                      className={`group text-5xl md:text-7xl font-black text-left uppercase tracking-tighter py-3 border-b border-zinc-50 hover:border-black transition-all ${activeCategory === cat ? 'text-black opacity-100' : 'text-zinc-200 hover:text-black'}`}
                    >
                      {cat}
                    </button>
                 ))}
               </div>
            </div>
          </div>

          {/* Bottom Footer Area in Menu */}
          <div className="mt-20 pt-12 border-t border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-8 pb-12">
             <div className="flex gap-10">
                <i className="fa-brands fa-facebook-f text-zinc-300 hover:text-black cursor-pointer transition-colors"></i>
                <i className="fa-brands fa-x-twitter text-zinc-300 hover:text-black cursor-pointer transition-colors"></i>
                <i className="fa-brands fa-linkedin-in text-zinc-300 hover:text-black cursor-pointer transition-colors"></i>
             </div>
             <p className="text-[9px] font-black tracking-[0.4em] text-zinc-300 uppercase">
                &copy; 2025 TELIER MEDIA GROUP GLOBAL LLC.
             </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
