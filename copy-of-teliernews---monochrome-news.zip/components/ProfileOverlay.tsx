
import React from 'react';
import { User } from '../types';

interface ProfileOverlayProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
}

const ProfileOverlay: React.FC<ProfileOverlayProps> = ({ user, isOpen, onClose, onLogout }) => {
  return (
    <>
      <div 
        onClick={onClose}
        className={`fixed inset-0 z-[110] bg-black/5 backdrop-blur-sm transition-opacity duration-700 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      ></div>

      <div className={`fixed top-0 right-0 h-full w-full max-w-xs bg-white z-[120] border-l border-zinc-100 shadow-2xl transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-10 flex flex-col h-full">
          <div className="flex justify-between items-center mb-12">
             <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-zinc-300">Identity Panel</span>
             <button onClick={onClose} className="hover:opacity-30 transition-opacity">
              <i className="fa-solid fa-xmark text-lg"></i>
            </button>
          </div>

          <div className="flex flex-col items-center text-center mb-16">
            <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center text-xl font-black mb-6">
              {user.name.charAt(0)}
            </div>
            <h3 className="text-2xl font-black tracking-tighter uppercase mb-1">{user.name}</h3>
            <p className="text-[9px] font-bold tracking-widest text-zinc-400 uppercase">{user.membership} LEVEL</p>
          </div>

          <div className="space-y-1">
            {['Archives', 'Briefings', 'Financials', 'Encryption'].map((item) => (
              <div key={item} className="flex justify-between items-center py-4 border-b border-zinc-100 cursor-pointer group">
                <span className="text-[10px] font-bold tracking-widest uppercase group-hover:pl-2 transition-all">{item}</span>
                <i className="fa-solid fa-chevron-right text-[10px] text-zinc-200"></i>
              </div>
            ))}
          </div>

          <div className="mt-auto">
            <button 
              onClick={() => { onLogout(); onClose(); }}
              className="w-full bg-black text-white py-4 text-[9px] font-black tracking-widest uppercase hover:bg-zinc-800 transition-all"
            >
              Terminate Session
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfileOverlay;
