
import React from 'react';
import { MOCK_MARKETS } from '../constants';

const MarketTicker: React.FC = () => {
  return (
    <div className="bg-zinc-50 text-black py-2.5 overflow-hidden whitespace-nowrap border-b border-black/5 select-none mt-20">
      <div className="inline-block animate-marquee">
        {Array(10).fill(MOCK_MARKETS).flat().map((item, idx) => (
          <span key={idx} className="mx-10 font-bold text-[10px] tracking-widest uppercase">
            {item.symbol} <span className="font-medium text-zinc-500 ml-1.5">{item.price}</span>
            <span className={`ml-2.5 font-black ${item.isPositive ? 'text-black' : 'text-zinc-400'}`}>
              {item.isPositive ? '+' : '-'} {item.change}
            </span>
          </span>
        ))}
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 80s linear infinite;
          display: inline-block;
        }
      `}</style>
    </div>
  );
};

export default MarketTicker;
