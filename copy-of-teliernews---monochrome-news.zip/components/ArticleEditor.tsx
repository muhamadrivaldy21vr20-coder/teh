
import React, { useState, useEffect } from 'react';
import { Article, Category } from '../types';
import { CATEGORIES } from '../constants';

interface ArticleEditorProps {
  article?: Article | null;
  onSave: (article: Partial<Article>) => void;
  onCancel: () => void;
}

const ArticleEditor: React.FC<ArticleEditorProps> = ({ article, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Partial<Article>>({
    title: '',
    excerpt: '',
    content: '',
    category: 'AI',
    imageUrl: '',
    author: 'Admin Editor'
  });

  useEffect(() => {
    if (article) setFormData(article);
  }, [article]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 z-[150] bg-white overflow-y-auto animate-in slide-in-from-right duration-700">
      <div className="max-w-4xl mx-auto px-6 py-20">
        <div className="flex justify-between items-center mb-16">
          <h2 className="text-3xl font-black tracking-tighter uppercase">
            {article ? 'Refine Intelligence' : 'Draft New Insight'}
          </h2>
          <button onClick={onCancel} className="text-zinc-400 hover:text-black transition-colors">
            <i className="fa-solid fa-xmark text-2xl"></i>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black tracking-[0.3em] uppercase text-zinc-300">Article Title</label>
                <input 
                  required
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  className="w-full text-2xl font-black border-b border-zinc-100 py-2 focus:outline-none focus:border-black transition-all uppercase tracking-tight"
                  placeholder="The Silent Rise of Neural Sovereignty"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black tracking-[0.3em] uppercase text-zinc-300">Classification</label>
                <select 
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value as Category})}
                  className="w-full bg-transparent border-b border-zinc-100 py-3 text-xs font-bold tracking-widest uppercase focus:outline-none focus:border-black transition-all cursor-pointer"
                >
                  {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black tracking-[0.3em] uppercase text-zinc-300">Visual Source (URL)</label>
                <input 
                  required
                  type="url"
                  value={formData.imageUrl}
                  onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                  className="w-full text-xs font-medium border-b border-zinc-100 py-3 focus:outline-none focus:border-black transition-all"
                  placeholder="https://images.unsplash.com/..."
                />
              </div>
            </div>

            <div className="space-y-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black tracking-[0.3em] uppercase text-zinc-300">Brief Excerpt</label>
                <textarea 
                  required
                  value={formData.excerpt}
                  onChange={(e) => setFormData({...formData, excerpt: e.target.value})}
                  rows={3}
                  className="w-full bg-zinc-50 p-4 text-xs font-medium leading-relaxed focus:outline-none focus:bg-zinc-100 transition-all border-l-2 border-transparent focus:border-black"
                  placeholder="Summarize the intelligence impact..."
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black tracking-[0.3em] uppercase text-zinc-300">Author Identity</label>
                <input 
                  type="text"
                  value={formData.author}
                  onChange={(e) => setFormData({...formData, author: e.target.value})}
                  className="w-full text-xs font-bold border-b border-zinc-100 py-3 focus:outline-none focus:border-black transition-all uppercase tracking-widest"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black tracking-[0.3em] uppercase text-zinc-300">Full Content Body</label>
            <textarea 
              required
              value={formData.content}
              onChange={(e) => setFormData({...formData, content: e.target.value})}
              rows={12}
              className="w-full border border-zinc-100 p-8 text-lg font-light leading-relaxed focus:outline-none focus:border-black transition-all bg-white"
              placeholder="Begin the analysis..."
            />
          </div>

          <div className="flex justify-end gap-6 pt-12 border-t border-zinc-100">
            <button 
              type="button"
              onClick={onCancel}
              className="text-[10px] font-black tracking-widest uppercase hover:opacity-50 transition-opacity"
            >
              Discard Changes
            </button>
            <button 
              type="submit"
              className="bg-black text-white px-12 py-5 text-[10px] font-black tracking-[0.2em] uppercase hover:bg-zinc-800 transition-all shadow-2xl"
            >
              Publish Intelligence
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ArticleEditor;
