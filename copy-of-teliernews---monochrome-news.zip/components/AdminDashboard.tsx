
import React from 'react';
import { Article } from '../types';

interface AdminDashboardProps {
  articles: Article[];
  onAddClick: () => void;
  onEditClick: (article: Article) => void;
  onDeleteClick: (id: string) => void;
  onExit: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  articles, 
  onAddClick, 
  onEditClick, 
  onDeleteClick,
  onExit 
}) => {
  return (
    <div className="min-h-screen bg-white pt-24 pb-12 px-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-12 pb-8 border-b border-black">
          <div>
            <p className="text-[10px] font-bold tracking-[0.4em] text-zinc-300 uppercase mb-2">Internal Terminal</p>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase">Content Management</h2>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={onExit}
              className="px-6 py-3 border border-zinc-100 text-[9px] font-black tracking-widest uppercase hover:bg-zinc-50 transition-all"
            >
              Exit Terminal
            </button>
            <button 
              onClick={onAddClick}
              className="px-8 py-3 bg-black text-white text-[9px] font-black tracking-widest uppercase hover:bg-zinc-800 transition-all"
            >
              Create New Article
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-1">
          <div className="grid grid-cols-12 px-6 py-3 border-b border-zinc-100 text-[8px] font-black tracking-[0.3em] text-zinc-300 uppercase">
            <div className="col-span-6">Intel Title</div>
            <div className="col-span-2">Category</div>
            <div className="col-span-2">Metrics</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          
          {articles.map((article) => (
            <div 
              key={article.id} 
              className="grid grid-cols-12 px-6 py-6 items-center border-b border-zinc-50 hover:bg-zinc-50 transition-colors group"
            >
              <div className="col-span-6 pr-8">
                <h4 className="text-sm font-black uppercase tracking-tight line-clamp-1">{article.title}</h4>
                <p className="text-[10px] text-zinc-400 uppercase tracking-widest mt-1">{article.date} — By {article.author}</p>
              </div>
              <div className="col-span-2">
                <span className="text-[9px] font-bold px-2 py-1 bg-zinc-100 uppercase tracking-widest">{article.category}</span>
              </div>
              <div className="col-span-2">
                <span className="text-[10px] font-medium text-zinc-400">{article.views || 0} READS</span>
              </div>
              <div className="col-span-2 text-right flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => onEditClick(article)}
                  className="p-2 hover:bg-black hover:text-white transition-all border border-zinc-100"
                >
                  <i className="fa-solid fa-pen-to-square text-xs"></i>
                </button>
                <button 
                  onClick={() => onDeleteClick(article.id)}
                  className="p-2 hover:bg-red-500 hover:text-white transition-all border border-zinc-100"
                >
                  <i className="fa-solid fa-trash-can text-xs"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
