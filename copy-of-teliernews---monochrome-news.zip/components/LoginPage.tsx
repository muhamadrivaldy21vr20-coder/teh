
import React, { useState } from 'react';

interface LoginPageProps {
  onLoginSuccess: (name: string, email: string) => void;
  onClose: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess, onClose }) => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      onLoginSuccess(email.split('@')[0], email);
      setIsLoading(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-white/40 backdrop-blur-xl animate-in fade-in duration-700">
      <div className="w-full max-w-sm bg-white p-10 border border-zinc-100 shadow-[0_32px_64px_-12px_rgba(0,0,0,0.1)] relative">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-zinc-300 hover:text-black transition-colors"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        <div className="text-center mb-10">
          <h2 className="text-xl font-black tracking-tighter uppercase mb-1">Terminal Access</h2>
          <p className="text-[9px] font-bold tracking-[0.4em] text-zinc-300 uppercase">Input Intelligence Credentials</p>
          <p className="text-[8px] text-zinc-400 mt-2 italic font-medium">Tip: Include 'admin' in email for CMS access</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[9px] font-black tracking-widest uppercase text-zinc-400">Network Email</label>
            <input 
              required
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border-b border-zinc-100 py-3 focus:outline-none focus:border-black transition-all text-xs font-medium"
              placeholder="IDENTITY@TELIER.NEWS"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-[9px] font-black tracking-widest uppercase text-zinc-400">Access Key</label>
            <input 
              required
              type="password" 
              className="w-full border-b border-zinc-100 py-3 focus:outline-none focus:border-black transition-all text-xs font-medium"
              placeholder="••••••••"
            />
          </div>

          <button 
            disabled={isLoading}
            className="w-full bg-black text-white py-4 font-black text-[10px] tracking-[0.2em] uppercase hover:bg-zinc-800 transition-all flex items-center justify-center"
          >
            {isLoading ? <i className="fa-solid fa-circle-notch fa-spin mr-3"></i> : 'VERIFY IDENTITY'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
