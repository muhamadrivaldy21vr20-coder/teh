
import { Article, MarketData, Category } from './types';

export const CATEGORIES: Category[] = [
  'Teknologi',
  'Ekonomi',
  'Politik',
  'Geopolitik',
  'Bisnis',
  'Internasional'
];

export const MOCK_ARTICLES: Article[] = [
  {
    id: '1',
    title: 'Kedaulatan Neural: Perlombaan Infrastruktur AI Global',
    excerpt: 'Bagaimana negara-negara berlomba membangun infrastruktur AI berdaulat untuk melindungi kepentingan nasional.',
    category: 'Teknologi',
    date: 'OCT 24, 2023',
    imageUrl: 'https://picsum.photos/seed/ai1/800/600',
    author: 'Elena Vance'
  },
  {
    id: '2',
    title: 'Pergeseran Tektonik Diplomasi Eurasia',
    excerpt: 'Analisis mendalam tentang evolusi aliansi di sepanjang Jalur Sutra dan dampaknya pada stabilitas perdagangan global.',
    category: 'Geopolitik',
    date: 'OCT 23, 2023',
    imageUrl: 'https://picsum.photos/seed/geo1/800/600',
    author: 'Marcus Thorne'
  },
  {
    id: '3',
    title: 'Denyut Pasar: Gema Deflasi Q4',
    excerpt: 'Bank sentral menghadapi tantangan baru saat pola pengeluaran konsumen bergeser drastis.',
    category: 'Ekonomi',
    date: 'OCT 22, 2023',
    imageUrl: 'https://picsum.photos/seed/mkt1/800/600',
    author: 'Sarah Chen'
  },
  {
    id: '4',
    title: 'Strategi Ekspansi Bisnis di Era Digital',
    excerpt: 'Mengapa perusahaan rintisan kini lebih fokus pada profitabilitas dibandingkan pertumbuhan eksponensial.',
    category: 'Bisnis',
    date: 'OCT 21, 2023',
    imageUrl: 'https://picsum.photos/seed/tech1/800/600',
    author: 'David Aris'
  }
];

export const MOCK_MARKETS: MarketData[] = [
  { symbol: 'TLR-IDX', price: '4,281.40', change: '+1.2%', isPositive: true },
  { symbol: 'BTC', price: '$68,421', change: '-0.4%', isPositive: false },
  { symbol: 'GOLD', price: '$2,730', change: '+0.8%', isPositive: true },
  { symbol: 'OIL', price: '$71.45', change: '-2.1%', isPositive: false }
];
